package schwartz.MAIN;

import java.io.IOException;

import schwartz.TASK.task;

public class MAIN {

	public static void main(String[] args) throws IOException {
		task.findFinalGrade("yourfilepath");
		task.hypothesizedGrade("yourfilepath");
		

	}

}
